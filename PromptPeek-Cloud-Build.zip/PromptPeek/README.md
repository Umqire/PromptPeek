# PromptPeek

Минимальное Android-приложение для просмотра текстовых PNG-метаданных генеративных изображений.

## Что умеет текущая версия
- Регистрируется как обработчик `image/png` для `ACTION_VIEW` и `ACTION_SEND`.
- Читает PNG `tEXt`, `zTXt`, `iTXt`.
- Показывает A1111 `parameters`, включая positive/negative prompt и параметры генерации.
- Для ComfyUI разбирает API JSON `prompt` и canvas workflow JSON.
- Если в workflow есть узел с заголовком `PromptPeek`, проходит по связям от его входа и собирает Positive Prompt, включая цепочки `StringConcatenate` и раскрытый текст `ImpactWildcardProcessor` (`populated_text`).
- Если узла `PromptPeek` нет, показывает найденные текстовые узлы как раньше.
- Работает локально, без разрешения на интернет.

## Сборка
Откройте папку проекта в Android Studio (Jellyfish или новее), дождитесь синхронизации Gradle и выберите Build → Build APK(s).

Требуется Android SDK Platform 35 и JDK 17 или новее. Минимальная версия Android — 6.0 (API 23).

## Ограничения первой версии
- Обрабатывает PNG, не JPEG/WebP.
- ComfyUI выводится как текстовые узлы; автоматическая классификация positive/negative зависит от названий узлов и графа.
- Некоторые приложения Files могут передавать URI только через `ACTION_SEND`; оба варианта зарегистрированы.
