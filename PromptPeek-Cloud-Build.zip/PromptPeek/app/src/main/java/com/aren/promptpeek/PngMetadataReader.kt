package com.aren.promptpeek

import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.nio.charset.Charset
import java.util.zip.InflaterInputStream

object PngMetadataReader {
    data class Entry(val key: String, val value: String)

    fun read(bytes: ByteArray): List<Entry> {
        val signature = byteArrayOf(137.toByte(), 80, 78, 71, 13, 10, 26, 10)
        require(bytes.size >= 8 && bytes.copyOfRange(0, 8).contentEquals(signature)) { "Это не PNG-файл" }
        val result = mutableListOf<Entry>()
        val input = DataInputStream(ByteArrayInputStream(bytes, 8, bytes.size - 8))
        while (input.available() >= 12) {
            val length = input.readInt()
            if (length < 0 || length > input.available() - 8) break
            val typeBytes = ByteArray(4); input.readFully(typeBytes)
            val data = ByteArray(length); input.readFully(data)
            input.skipBytes(4) // CRC
            val type = String(typeBytes, Charsets.US_ASCII)
            when (type) {
                "tEXt" -> {
                    val split = data.indexOf(0)
                    if (split > 0) result += Entry(String(data, 0, split, Charsets.ISO_8859_1), String(data, split + 1, data.size - split - 1, Charsets.ISO_8859_1))
                }
                "zTXt" -> {
                    val split = data.indexOf(0)
                    if (split > 0 && split + 2 <= data.size) {
                        val key = String(data, 0, split, Charsets.ISO_8859_1)
                        val decoded = inflate(data.copyOfRange(split + 2, data.size))
                        result += Entry(key, decoded)
                    }
                }
                "iTXt" -> parseInternational(data)?.let { result += it }
                "IEND" -> break
            }
        }
        return result
    }

    private fun parseInternational(data: ByteArray): Entry? {
        var p = data.indexOf(0)
        if (p <= 0 || p + 3 >= data.size) return null
        val key = String(data, 0, p, Charsets.ISO_8859_1)
        p++
        val compressed = data[p++].toInt() != 0
        p++ // compression method
        p = nextZero(data, p) + 1 // language tag
        if (p <= 0 || p > data.size) return null
        p = nextZero(data, p) + 1 // translated keyword
        if (p <= 0 || p > data.size) return null
        val payload = data.copyOfRange(p, data.size)
        return Entry(key, if (compressed) inflate(payload) else String(payload, Charsets.UTF_8))
    }

    private fun nextZero(data: ByteArray, from: Int): Int {
        for (i in from until data.size) if (data[i].toInt() == 0) return i
        return -1
    }

    private fun inflate(data: ByteArray): String = try {
        InflaterInputStream(ByteArrayInputStream(data)).use { it.readBytes().toString(Charsets.UTF_8) }
    } catch (_: Exception) { "[Не удалось распаковать текстовый блок]" }

    fun describe(entries: List<Entry>): String {
        if (entries.isEmpty()) return "В PNG не найдены текстовые метаданные. Возможно, файл был пересохранён или метаданные удалены."
        val out = StringBuilder()
        entries.forEach { entry ->
            out.append("━━ ").append(entry.key).append(" ━━\n")
            val value = entry.value.trim()
            when (entry.key.lowercase()) {
                "parameters" -> out.append(formatA1111(value))
                "prompt", "workflow" -> out.append(formatComfy(value))
                else -> out.append(value)
            }
            out.append("\n\n")
        }
        return out.toString().trim()
    }

    private fun formatA1111(value: String): String {
        val negative = Regex("\\nNegative prompt:\\s*").find(value)
        val settings = Regex("\\nSteps:\\s*").find(value)
        val positiveEnd = listOfNotNull(negative?.range?.first, settings?.range?.first).minOrNull() ?: value.length
        val positive = value.substring(0, positiveEnd).trim()
        val result = StringBuilder("POSITIVE PROMPT\n$positive")
        if (negative != null) {
            val end = settings?.range?.first ?: value.length
            result.append("\n\nNEGATIVE PROMPT\n").append(value.substring(negative.range.last + 1, end).trim())
        }
        if (settings != null) result.append("\n\nПАРАМЕТРЫ\n").append(value.substring(settings.range.first).trim())
        return result.toString()
    }

    private fun formatComfy(value: String): String {
        return try {
            val root = JSONObject(value)
            val prompt = if (root.has("prompt") && root.opt("prompt") is JSONObject) root.getJSONObject("prompt") else root
            val lines = mutableListOf<String>()
            val keys = prompt.keys()
            while (keys.hasNext()) {
                val id = keys.next()
                val node = prompt.optJSONObject(id) ?: continue
                val type = node.optString("class_type", node.optString("type", ""))
                val inputs = node.optJSONObject("inputs")
                val text = inputs?.opt("text")
                if (text is String && text.isNotBlank()) {
                    val title = node.optJSONObject("_meta")?.optString("title")?.takeIf { it.isNotBlank() } ?: type
                    lines += "[$title · node $id]\n$text"
                }
            }
            if (lines.isNotEmpty()) "ТЕКСТОВЫЕ УЗЛЫ COMFYUI\n\n" + lines.joinToString("\n\n") else value
        } catch (_: Exception) { value }
    }
}
