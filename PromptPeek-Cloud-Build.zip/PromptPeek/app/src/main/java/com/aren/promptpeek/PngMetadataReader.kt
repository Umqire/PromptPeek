package com.aren.promptpeek

import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.nio.charset.Charset
import java.util.zip.InflaterInputStream

object PngMetadataReader {
    data class Entry(val key: String, val value: String)

    fun read(bytes: ByteArray): List<Entry> {
        val signature = byteArrayOf(137.toByte(), 80, 78, 71, 13, 10, 26, 10)
        require(bytes.size >= 8 && bytes.copyOfRange(0, 8).contentEquals(signature)) { "Это не PNG-файл" }
        val result = mutableListOf<Entry>()
        val input = DataInputStream(ByteArrayInputStream(bytes, 8, bytes.size - 8))
        while (input.available() >= 12) {
            val length = input.readInt()
            if (length < 0 || length > input.available() - 8) break
            val typeBytes = ByteArray(4); input.readFully(typeBytes)
            val data = ByteArray(length); input.readFully(data)
            input.skipBytes(4) // CRC
            val type = String(typeBytes, Charsets.US_ASCII)
            when (type) {
                "tEXt" -> {
                    val split = data.indexOf(0)
                    if (split > 0) result += Entry(String(data, 0, split, Charsets.ISO_8859_1), String(data, split + 1, data.size - split - 1, Charsets.ISO_8859_1))
                }
                "zTXt" -> {
                    val split = data.indexOf(0)
                    if (split > 0 && split + 2 <= data.size) {
                        val key = String(data, 0, split, Charsets.ISO_8859_1)
                        val decoded = inflate(data.copyOfRange(split + 2, data.size))
                        result += Entry(key, decoded)
                    }
                }
                "iTXt" -> parseInternational(data)?.let { result += it }
                "IEND" -> break
            }
        }
        return result
    }

    private fun parseInternational(data: ByteArray): Entry? {
        var p = data.indexOf(0)
        if (p <= 0 || p + 3 >= data.size) return null
        val key = String(data, 0, p, Charsets.ISO_8859_1)
        p++
        val compressed = data[p++].toInt() != 0
        p++ // compression method
        p = nextZero(data, p) + 1 // language tag
        if (p <= 0 || p > data.size) return null
        p = nextZero(data, p) + 1 // translated keyword
        if (p <= 0 || p > data.size) return null
        val payload = data.copyOfRange(p, data.size)
        return Entry(key, if (compressed) inflate(payload) else String(payload, Charsets.UTF_8))
    }

    private fun nextZero(data: ByteArray, from: Int): Int {
        for (i in from until data.size) if (data[i].toInt() == 0) return i
        return -1
    }

    private fun inflate(data: ByteArray): String = try {
        InflaterInputStream(ByteArrayInputStream(data)).use { it.readBytes().toString(Charsets.UTF_8) }
    } catch (_: Exception) { "[Не удалось распаковать текстовый блок]" }

    fun describe(entries: List<Entry>): String {
        if (entries.isEmpty()) return "В PNG не найдены текстовые метаданные. Возможно, файл был пересохранён или метаданные удалены."
        val out = StringBuilder()
        entries.forEach { entry ->
            out.append("━━ ").append(entry.key).append(" ━━\n")
            val value = entry.value.trim()
            when (entry.key.lowercase()) {
                "parameters" -> out.append(formatA1111(value))
                "prompt", "workflow" -> out.append(formatComfy(value))
                else -> out.append(value)
            }
            out.append("\n\n")
        }
        return out.toString().trim()
    }

    private fun formatA1111(value: String): String {
        val negative = Regex("\\nNegative prompt:\\s*").find(value)
        val settings = Regex("\\nSteps:\\s*").find(value)
        val positiveEnd = listOfNotNull(negative?.range?.first, settings?.range?.first).minOrNull() ?: value.length
        val positive = value.substring(0, positiveEnd).trim()
        val result = StringBuilder("POSITIVE PROMPT\n$positive")
        if (negative != null) {
            val end = settings?.range?.first ?: value.length
            result.append("\n\nNEGATIVE PROMPT\n").append(value.substring(negative.range.last + 1, end).trim())
        }
        if (settings != null) result.append("\n\nПАРАМЕТРЫ\n").append(value.substring(settings.range.first).trim())
        return result.toString()
    }

    private fun formatComfy(value: String): String {
        return try {
            val root = JSONObject(value)
            val workflow = root.optJSONArray("nodes")
            if (workflow != null) {
                formatWorkflow(root, workflow, value)
            } else {
                val prompt = if (root.has("prompt") && root.opt("prompt") is JSONObject) root.getJSONObject("prompt") else root
                formatApiPrompt(prompt, value)
            }
        } catch (_: Exception) { value }
    }

    // ComfyUI canvas JSON: display the text chain connected to the PromptPeek input.
    private fun formatWorkflow(root: JSONObject, nodes: org.json.JSONArray, original: String): String {
        val byId = mutableMapOf<String, JSONObject>()
        for (i in 0 until nodes.length()) {
            val node = nodes.optJSONObject(i) ?: continue
            byId[node.opt("id").toString()] = node
        }

        // link: [link id, source node id, source slot, target node id, target slot, type]
        val links = mutableMapOf<String, Pair<String, Int>>()
        val linkArray = root.optJSONArray("links") ?: org.json.JSONArray()
        for (i in 0 until linkArray.length()) {
            val link = linkArray.optJSONArray(i) ?: continue
            if (link.length() >= 5) links[link.opt(0).toString()] =
                link.opt(1).toString() to link.optInt(2)
        }

        fun widget(node: JSONObject, name: String): String? {
            val named = node.optJSONObject("widgets_values_named")
            if (named != null && named.has(name)) {
                val v = named.opt(name)
                if (v is String && v.isNotBlank()) return v
            }
            // Common widgets_values order for StringConcatenate.
            val type = node.optString("type")
            val values = node.optJSONArray("widgets_values") ?: return null
            val index = when (type) {
                "StringConcatenate" -> when (name) { "string_a" -> 0; "string_b" -> 1; "delimiter" -> 2; else -> -1 }
                "CLIPTextEncode" -> if (name == "text") 0 else -1
                else -> -1
            }
            if (index >= 0 && index < values.length()) {
                val v = values.opt(index)
                if (v is String && v.isNotBlank()) return v
            }
            return null
        }

        val resolving = mutableSetOf<String>()
        fun resolve(nodeId: String, slot: Int = 0, depth: Int = 0): String {
            if (depth > 40 || nodeId in resolving) return ""
            val node = byId[nodeId] ?: return ""
            val type = node.optString("type")
            resolving.add(nodeId)
            try {
                // Impact Pack stores the expanded wildcard result separately from its template.
                val named = node.optJSONObject("widgets_values_named")
                if (type.contains("ImpactWildcardProcessor", true)) {
                    val expanded = named?.optString("populated_text", "")?.takeIf { it.isNotBlank() }
                    if (expanded != null) return expanded
                }

                val inputs = node.optJSONArray("inputs") ?: org.json.JSONArray()
                if (type == "StringConcatenate") {
                    // Some versions omit unconnected STRING inputs from the inputs array
                    // (for example node 409 has only string_a connected, while string_b
                    // remains a widget). Preserve both linked values and literal widgets.
                    val inputNames = linkedSetOf<String>()
                    for (i in 0 until inputs.length()) {
                        inputs.optJSONObject(i)?.optString("name")
                            ?.takeIf { it.isNotBlank() }?.let { inputNames += it }
                    }
                    val namedValues = node.optJSONObject("widgets_values_named")
                    listOf("string_a", "string_b").forEach { name ->
                        if (namedValues?.has(name) == true) inputNames += name
                    }
                    val parts = mutableListOf<String>()
                    for (name in inputNames) {
                        val input = (0 until inputs.length()).mapNotNull { inputs.optJSONObject(it) }
                            .firstOrNull { it.optString("name") == name }
                        val linkedId = input?.opt("link")
                            ?.takeIf { it !is org.json.JSONObject && it !is org.json.JSONArray && it.toString() != "null" }
                            ?.toString()
                        val linked = linkedId?.let { links[it] }
                        val part = if (linked != null) resolve(linked.first, linked.second, depth + 1)
                                   else widget(node, name).orEmpty()
                        if (part.isNotEmpty()) parts += part
                    }
                    val delimiter = widget(node, "delimiter").orEmpty()
                    return parts.joinToString(delimiter)
                }

                // PromptsFromTextbox may expose its evaluated output in metadata in some
                // node versions. Never substitute wildcard_text: that is only a template.
                if (type == "PromptsFromTextbox") {
                    val evaluated = sequenceOf("populated_text", "output_text", "prompt", "text")
                        .mapNotNull { named?.optString(it)?.takeIf(String::isNotBlank) }
                        .firstOrNull()
                    if (evaluated != null) return evaluated
                    return ""
                }

                // For text encoder nodes use the actual text widget, not the CLIP input.
                if (type == "CLIPTextEncode" || type.contains("TextEncode", true)) {
                    widget(node, "text")?.let { return it }
                }

                // Generic pass-through: follow linked inputs, then look for populated/plain text widgets.
                val collected = mutableListOf<String>()
                for (i in 0 until inputs.length()) {
                    val input = inputs.optJSONObject(i) ?: continue
                    val linkId = input.opt("link")?.toString()
                    val linked = linkId?.let { links[it] }
                    if (linked != null) {
                        val text = resolve(linked.first, linked.second, depth + 1)
                        if (text.isNotBlank()) collected += text
                    }
                }
                if (collected.isNotEmpty()) return collected.joinToString(" ")
                val expanded = named?.optString("populated_text", "")?.takeIf { it.isNotBlank() }
                if (expanded != null) return expanded
                val plain = named?.optString("text", "")?.takeIf { it.isNotBlank() }
                if (plain != null) return plain
                val wildcard = named?.optString("wildcard_text", "")?.takeIf { it.isNotBlank() }
                if (wildcard != null) return wildcard
                return ""
            } finally {
                resolving.remove(nodeId)
            }
        }

        val markers = (0 until nodes.length()).mapNotNull { nodes.optJSONObject(it) }
            .filter { it.optString("title").trim().equals("PromptPeek", ignoreCase = true) }
        val lines = mutableListOf<String>()
        markers.forEachIndexed { index, marker ->
            val markerInputs = marker.optJSONArray("inputs") ?: org.json.JSONArray()
            val source = (0 until markerInputs.length()).mapNotNull { markerInputs.optJSONObject(it) }
                .firstNotNullOfOrNull { input ->
                    val id = input.opt("link")?.toString()
                    id?.let { links[it] }
                }
            if (source != null) {
                val text = resolve(source.first, source.second).trim()
                if (text.isNotEmpty()) lines += "POSITIVE PROMPT${if (markers.size > 1) " · PromptPeek ${index + 1}" else ""}\n$text"
            }
        }

        // If there is no PromptPeek marker, retain the previous useful text-node view.
        if (lines.isEmpty()) {
            for (i in 0 until nodes.length()) {
                val node = nodes.optJSONObject(i) ?: continue
                val type = node.optString("type")
                val text = widget(node, "text")
                if (text != null) {
                    val title = node.optString("title").takeIf { it.isNotBlank() } ?: type
                    lines += "[$title · node ${node.opt("id")}]\n$text"
                }
            }
        }
        return if (lines.isNotEmpty()) "ТЕКСТОВЫЕ УЗЛЫ COMFYUI\n\n" + lines.joinToString("\n\n") else original
    }

    private fun formatApiPrompt(prompt: JSONObject, original: String): String {
        val lines = mutableListOf<String>()
        val keys = prompt.keys()
        while (keys.hasNext()) {
            val id = keys.next()
            val node = prompt.optJSONObject(id) ?: continue
            val type = node.optString("class_type", node.optString("type", ""))
            val inputs = node.optJSONObject("inputs")
            val text = inputs?.opt("text")
            if (text is String && text.isNotBlank()) {
                val title = node.optJSONObject("_meta")?.optString("title")?.takeIf { it.isNotBlank() } ?: type
                lines += "[$title · node $id]\n$text"
            }
        }
        return if (lines.isNotEmpty()) "ТЕКСТОВЫЕ УЗЛЫ COMFYUI\n\n" + lines.joinToString("\n\n") else original
    }
}
