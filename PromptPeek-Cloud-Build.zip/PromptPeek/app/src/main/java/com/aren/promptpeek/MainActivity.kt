package com.aren.promptpeek

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var content: TextView
    private lateinit var filename: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 16)
            setBackgroundColor(Color.rgb(8, 20, 38))
        }
        val title = TextView(this).apply {
            text = "PromptPeek"
            textSize = 26f
            setTextColor(Color.WHITE)
        }
        filename = TextView(this).apply {
            text = "Открой PNG через Files → Открыть с помощью"
            textSize = 14f
            setTextColor(Color.rgb(150, 175, 200))
            setPadding(0, 8, 0, 16)
        }
        val copy = Button(this).apply {
            text = "Копировать весь текст"
            setOnClickListener {
                val clip = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clip.setPrimaryClip(android.content.ClipData.newPlainText("PNG prompt", content.text))
                text = "Скопировано"
            }
        }
        content = TextView(this).apply {
            text = "Здесь появятся промпты и метаданные изображения."
            textSize = 15f
            setTextColor(Color.rgb(230, 238, 248))
            setTextIsSelectable(true)
            setPadding(14, 14, 14, 24)
        }
        val scroll = ScrollView(this).apply {
            addView(content, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        root.addView(title)
        root.addView(filename)
        root.addView(copy)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun handleIntent(intent: Intent?) {
        val uri: Uri? = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            else -> null
        }
        if (uri == null) return
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Не удалось прочитать файл")
            val entries = PngMetadataReader.read(bytes)
            filename.text = uri.lastPathSegment?.substringAfterLast('/') ?: "PNG image"
            content.text = PngMetadataReader.describe(entries)
        } catch (e: Exception) {
            content.text = "Ошибка чтения: ${e.message ?: "неизвестная ошибка"}"
        }
    }
}
